# NOVA AI — Android starter project

यह एक शुरुआती Android Studio प्रोजेक्ट है: Kotlin + Jetpack Compose UI, Android speech-to-text, Android Text-to-Speech, और Gemini/OpenAI Hybrid backend.

## इसमें क्या काम करता है
- Chat UI और संदेश भेजना
- Android speech recognition से आवाज़ को टेक्स्ट में बदलना
- Android Text-to-Speech से AI जवाब पढ़ना
- Backend में Gemini पहले, असफल होने पर OpenAI fallback
- API keys केवल backend `.env` में रखी जाती हैं

## अभी क्या नहीं है
यह पहला starter build है, पूर्ण system-level assistant नहीं। यह अपने-आप फोन कॉल नहीं करता, WhatsApp/SMS नहीं भेजता, लॉक स्क्रीन से हमेशा सुनता नहीं, और alarm/calendar जैसी कार्रवाइयाँ अभी जोड़ी नहीं गई हैं। ऐसी सुविधाओं के लिए अलग Android permissions, user confirmation और feature modules चाहिए।

## आवश्यक चीजें
- Android Studio का वर्तमान stable संस्करण
- JDK 17
- इंटरनेट कनेक्शन
- Gemini और/या OpenAI API key; API usage पर शुल्क/limits लागू हो सकते हैं

## Android Studio में खोलना
1. ZIP extract करें।
2. Android Studio → Open → `NOVA_AI_Android_Project` फ़ोल्डर चुनें।
3. Gradle sync पूरा होने दें। Android SDK Platform 35 और JDK 17 इंस्टॉल रखें।
4. `MainActivity.kt` में `API_BASE_URL` को अपने deployed HTTPS backend URL से बदलें।
5. फोन में Developer Options → USB debugging चालू करके फोन connect करें, या emulator चलाएँ।
6. Run ▶ दबाएँ।

## Backend चलाना
1. Node.js 20 या नया इंस्टॉल करें।
2. Terminal में `backend` फ़ोल्डर खोलें।
3. `npm install` चलाएँ।
4. `.env.example` की कॉपी बनाकर उसका नाम `.env` रखें।
5. `.env` में अपनी Gemini/OpenAI API keys डालें। कम-से-कम एक provider key जरूरी है।
6. `npm start` चलाएँ।
7. `/health` endpoint पर `{ "ok": true }` आना चाहिए।
8. Backend को सुरक्षित HTTPS hosting पर deploy करें। सार्वजनिक ऐप के लिए rate limiting, authentication, abuse protection और usage limits जोड़ें।

### Hybrid व्यवहार
- Backend पहले Gemini को call करता है।
- Gemini unavailable हो या error दे तो OpenAI fallback होता है।
- दोनों fail हों तो app में error संदेश दिखता है।
- यदि आपके API account में चुना model उपलब्ध न हो, `.env` में `GEMINI_MODEL` या `OPENAI_MODEL` बदलें।

## APK बनाना
1. Android Studio में project sync और Run सफल करें।
2. Build → Build Bundle(s) / APK(s) → Build APK(s) चुनें।
3. Build पूरा होने पर Android Studio में “locate” चुनें।
4. Debug APK सामान्यतः `app/build/outputs/apk/debug/app-debug.apk` में मिलेगा।
5. Release APK के लिए Build → Generate Signed Bundle / APK → APK चुनें, नया keystore بنائیں और सुरक्षित backup रखें। Keystore/password کسی کے ساتھ share نہ करें۔

## API URL نوٹ
- `https://YOUR_BACKEND_HOST` placeholder ہے، اسے اپنے backend کے حقیقی HTTPS URL سے بدلیں۔
- Local testing میں emulator کے لیے host machine کا special address `10.0.2.2` ہے، مثلاً `http://10.0.2.2:3000`؛ مگر manifest میں cleartext HTTP بند ہے، اس لیے local HTTP testing کے لیے debug-only network security config بنانا ہوگا۔ بہتر ہے HTTPS staging URL استعمال کریں۔
- Physical phone पर `localhost` फोन को दर्शाता है, आपका computer नहीं।

## सुरक्षा
- API keys को APK, Kotlin source, Git repository या screenshots में न डालें।
- Microphone का उपयोग केवल user द्वारा mic button दबाने पर होता है।
- यह starter app speech service की उपलब्धता पर निर्भर है।
- API calls internet के जरिए backend तक जाती हैं। संवेदनशील निजी जानकारी न भेजें।


## Hey NOVA — Both Mode (experimental)
- Chat screen का microphone button Tap-to-Talk है।
- "Hey NOVA wake listening" switch से user खुद listening session शुरू/बंद करता है।
- Active session के दौरान Android foreground microphone service और ongoing notification रहती है; notification में Stop listening action है।
- Wake phrase detect होने पर एक अलग notification आती है; उसे tap करके NOVA app खोलें। यह ऐप को चुपचाप foreground में नहीं लाता।
- Android SpeechRecognizer dedicated low-power hotword engine नहीं है। Recognition device/vendor, speech service, language और network पर निर्भर करती है; continuous restart battery और data खर्च कर सकता है। यह हमेशा सही wake-word detection की गारंटी नहीं देता।
- Android 14+ पर microphone foreground service केवल तब शुरू करें जब app visible हो और RECORD_AUDIO permission grant हो। Android OS/background restrictions को bypass करने की कोशिश न करें।
- Hindi wake phrase recognition device पर निर्भर है; इस sample में English "Hey NOVA" और देवनागरी "हे नोवा" matching शामिल है। वास्तविक product के लिए licensed/on-device keyword spotting engine और स्पष्ट privacy UX बेहतर है।
