package com.novaai.assistant

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import androidx.core.app.NotificationCompat
import java.util.Locale

/**
 * User-started wake-word session.
 * Android's SpeechRecognizer is not a dedicated always-on hotword engine;
 * availability, network use and battery impact vary by device.
 */
class WakeWordService : Service() {
    private var recognizer: SpeechRecognizer? = null
    private val handler = Handler(Looper.getMainLooper())
    private var isListening = false
    private var lastWakeAt = 0L

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSession()
            return START_NOT_STICKY
        }

        val notification = buildNotification("Listening session is active")
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(
                NOTIFICATION_ID,
                notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
            )
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }

        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            updateNotification("Speech recognition is not available on this device")
            stopSession()
            return START_NOT_STICKY
        }

        if (recognizer == null) {
            recognizer = SpeechRecognizer.createSpeechRecognizer(this).also { sr ->
                sr.setRecognitionListener(object : RecognitionListener {
                    override fun onReadyForSpeech(params: android.os.Bundle?) {
                        isListening = true
                    }
                    override fun onBeginningOfSpeech() {}
                    override fun onRmsChanged(rmsdB: Float) {}
                    override fun onBufferReceived(buffer: ByteArray?) {}
                    override fun onEndOfSpeech() { isListening = false }

                    override fun onError(error: Int) {
                        isListening = false
                        scheduleListen(1200)
                    }

                    override fun onResults(results: android.os.Bundle?) {
                        isListening = false
                        val heard = results
                            ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                            ?.firstOrNull()
                            .orEmpty()
                        if (isWakePhrase(heard)) {
                            val now = System.currentTimeMillis()
                            if (now - lastWakeAt > 5000) {
                                lastWakeAt = now
                                updateNotification("Hey NOVA detected — tap notification to open")
                                showWakeNotification()
                            }
                        }
                        scheduleListen(900)
                    }

                    override fun onPartialResults(partialResults: android.os.Bundle?) {
                        val heard = partialResults
                            ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                            ?.firstOrNull()
                            .orEmpty()
                        if (isWakePhrase(heard)) {
                            val now = System.currentTimeMillis()
                            if (now - lastWakeAt > 5000) {
                                lastWakeAt = now
                                updateNotification("Hey NOVA detected — tap notification to open")
                                showWakeNotification()
                            }
                        }
                    }

                    override fun onEvent(eventType: Int, params: android.os.Bundle?) {}
                })
            }
        }
        scheduleListen(300)
        return START_STICKY
    }

    private fun isWakePhrase(text: String): Boolean {
        val normalized = text.lowercase(Locale.ROOT)
            .replace(",", " ").replace(".", " ").trim()
        return normalized.contains("hey nova") ||
            normalized.contains("हे नोवा") ||
            normalized.contains("हे नोभा")
    }

    private fun scheduleListen(delayMs: Long) {
        handler.removeCallbacks(listenRunnable)
        handler.postDelayed(listenRunnable, delayMs)
    }

    private val listenRunnable = Runnable {
        val sr = recognizer ?: return@Runnable
        if (!isListening) {
            try {
                val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE, "en-IN")
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "en-IN")
                    putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                    putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
                }
                sr.startListening(intent)
                isListening = true
            } catch (_: SecurityException) {
                updateNotification("Microphone permission is required")
                stopSession()
            } catch (_: Exception) {
                scheduleListen(2000)
            }
        }
    }

    private fun showWakeNotification() {
        val manager = getSystemService(NotificationManager::class.java)
        manager.notify(WAKE_NOTIFICATION_ID, buildWakeNotification())
    }

    private fun buildWakeNotification(): Notification {
        val openIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val pending = PendingIntent.getActivity(
            this, 2, openIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("NOVA AI heard its wake phrase")
            .setContentText("Tap to open NOVA AI")
            .setContentIntent(pending)
            .setAutoCancel(true)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .build()
    }

    private fun buildNotification(message: String): Notification {
        val stopIntent = Intent(this, WakeWordService::class.java).apply { action = ACTION_STOP }
        val stopPending = PendingIntent.getService(
            this, 1, stopIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("NOVA AI — Wake listening")
            .setContentText(message)
            .setOngoing(true)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .addAction(android.R.drawable.ic_media_pause, "Stop listening", stopPending)
            .build()
    }

    private fun updateNotification(message: String) {
        getSystemService(NotificationManager::class.java)
            .notify(NOTIFICATION_ID, buildNotification(message))
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(
                CHANNEL_ID, "NOVA AI voice session", NotificationManager.IMPORTANCE_LOW
            )
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun stopSession() {
        handler.removeCallbacksAndMessages(null)
        try { recognizer?.cancel() } catch (_: Exception) {}
        try { recognizer?.destroy() } catch (_: Exception) {}
        recognizer = null
        isListening = false
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        try { recognizer?.destroy() } catch (_: Exception) {}
        recognizer = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        const val ACTION_STOP = "com.novaai.assistant.STOP_WAKE_SESSION"
        private const val CHANNEL_ID = "nova_voice_session"
        private const val NOTIFICATION_ID = 4101
        private const val WAKE_NOTIFICATION_ID = 4102
    }
}
