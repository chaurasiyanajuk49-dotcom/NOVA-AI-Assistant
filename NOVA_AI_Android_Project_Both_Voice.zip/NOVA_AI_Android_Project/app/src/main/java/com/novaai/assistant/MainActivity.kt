package com.novaai.assistant

import android.content.Intent
import android.os.Bundle
import android.os.Build
import android.Manifest
import android.content.Context
import androidx.core.content.ContextCompat
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Send
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale

private const val API_BASE_URL = "https://YOUR_BACKEND_HOST"

class MainActivity : ComponentActivity(), TextToSpeech.OnInitListener {
    private var tts: TextToSpeech? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        setContent { NovaScreen(onSpeak = { speak(it) }) }
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) tts?.language = Locale("hi", "IN")
    }

    private fun speak(text: String) {
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "nova_reply")
    }

    override fun onDestroy() {
        tts?.stop()
        tts?.shutdown()
        super.onDestroy()
    }
}

data class ChatMessage(val text: String, val isUser: Boolean)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NovaScreen(onSpeak: (String) -> Unit) {
    val messages = remember { mutableStateListOf(ChatMessage("नमस्ते! मैं NOVA AI हूँ। मुझसे हिंदी या English में बात करें।", false)) }
    var input by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf("Ready") }
    var wakeSessionOn by remember { mutableStateOf(false) }
    val context = androidx.compose.ui.platform.LocalContext.current
    val scope = rememberCoroutineScope()

    val notificationPermission = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { /* Android still shows the required foreground-service notice where applicable. */ }

    val wakeMicPermission = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            if (Build.VERSION.SDK_INT >= 33) {
                notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
            val serviceIntent = Intent(context, WakeWordService::class.java)
            try {
                if (Build.VERSION.SDK_INT >= 26) context.startForegroundService(serviceIntent)
                else context.startService(serviceIntent)
                wakeSessionOn = true
                status = "Hey NOVA listening session started"
            } catch (_: Exception) {
                status = "Could not start voice session. Check permissions."
            }
        } else {
            status = "Microphone permission is required for Hey NOVA."
        }
    }

    fun startWakeSession() {
        wakeMicPermission.launch(Manifest.permission.RECORD_AUDIO)
    }

    fun stopWakeSession() {
        context.stopService(Intent(context, WakeWordService::class.java))
        wakeSessionOn = false
        status = "Wake listening stopped"
    }

    val speechLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        val spoken = result.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
        if (!spoken.isNullOrBlank()) input = spoken
    }

    val microphonePermission = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            try {
                val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
                    putExtra(RecognizerIntent.EXTRA_PROMPT, "NOVA से बात करें / Speak to NOVA")
                }
                speechLauncher.launch(intent)
            } catch (_: Exception) {
                status = "इस फोन में Speech Recognition उपलब्ध नहीं है।"
            }
        } else {
            status = "Voice input के लिए microphone permission जरूरी है।"
        }
    }

    fun startVoiceInput() {
        microphonePermission.launch(android.Manifest.permission.RECORD_AUDIO)
    }

    fun sendMessage() {
        val question = input.trim()
        if (question.isEmpty() || busy) return
        messages.add(ChatMessage(question, true))
        input = ""
        busy = true
        status = "NOVA सोच रहा है..."
        scope.launch {
            val answer = withContext(Dispatchers.IO) { callNovaApi(question) }
            messages.add(ChatMessage(answer, false))
            busy = false
            status = "Ready"
            onSpeak(answer)
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("NOVA AI", color = Color.White)
                        Text("Personal Phone Assistant", style = MaterialTheme.typography.labelSmall, color = Color(0xFFB9C9FF))
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color(0xFF111A35))
            )
        },
        containerColor = Color(0xFF080E20)
    ) { padding ->
        Column(
            Modifier.fillMaxSize().padding(padding).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth().background(Color(0xFF131E38), RoundedCornerShape(16.dp)).padding(horizontal = 14.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column(Modifier.weight(1f)) {
                    Text("Hey NOVA wake listening", color = Color.White, style = MaterialTheme.typography.titleSmall)
                    Text(
                        if (wakeSessionOn) "Listening session active • notification shown" else "Off • tap to start a listening session",
                        color = Color(0xFFB9C9FF), style = MaterialTheme.typography.labelSmall
                    )
                }
                Switch(
                    checked = wakeSessionOn,
                    onCheckedChange = { enabled -> if (enabled) startWakeSession() else stopWakeSession() }
                )
            }

            Box(
                Modifier.fillMaxWidth().height(130.dp)
                    .background(Brush.linearGradient(listOf(Color(0xFF172D63), Color(0xFF492D79))), RoundedCornerShape(24.dp)),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("✦", style = MaterialTheme.typography.headlineLarge, color = Color(0xFF91C7FF))
                    Text("Hello, I'm NOVA", color = Color.White, style = MaterialTheme.typography.titleLarge)
                    Text(status, color = Color(0xFFCCD8FF), style = MaterialTheme.typography.labelMedium)
                }
            }

            LazyColumn(
                modifier = Modifier.weight(1f).fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(messages) { message ->
                    Row(
                        Modifier.fillMaxWidth(),
                        horizontalArrangement = if (message.isUser) Arrangement.End else Arrangement.Start
                    ) {
                        Surface(
                            color = if (message.isUser) Color(0xFF284C91) else Color(0xFF192440),
                            shape = RoundedCornerShape(18.dp),
                            modifier = Modifier.widthIn(max = 310.dp)
                        ) {
                            Text(message.text, color = Color.White, modifier = Modifier.padding(13.dp))
                        }
                    }
                }
            }

            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = input,
                    onValueChange = { input = it },
                    modifier = Modifier.weight(1f),
                    placeholder = { Text("Message NOVA...") },
                    maxLines = 3,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = Color.White, unfocusedTextColor = Color.White,
                        focusedBorderColor = Color(0xFF779EFF), unfocusedBorderColor = Color(0xFF526080),
                        focusedPlaceholderColor = Color.LightGray, unfocusedPlaceholderColor = Color.LightGray
                    )
                )
                FilledIconButton(onClick = { startVoiceInput() }, modifier = Modifier.size(48.dp)) {
                    Icon(Icons.Default.Mic, contentDescription = "Voice input")
                }
                FilledIconButton(onClick = { sendMessage() }, enabled = !busy, modifier = Modifier.size(48.dp)) {
                    Icon(Icons.Default.Send, contentDescription = "Send")
                }
            }
            Text("Voice recognition and replies use Android services. AI replies need your own configured backend.", color = Color(0xFF9AA8C7), style = MaterialTheme.typography.labelSmall)
        }
    }
}

private fun callNovaApi(message: String): String {
    return try {
        val url = URL("$API_BASE_URL/chat")
        val connection = (url.openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 20000
            readTimeout = 60000
            doOutput = true
            setRequestProperty("Content-Type", "application/json")
        }
        val payload = JSONObject()
            .put("message", message)
            .put("provider", "hybrid")
        connection.outputStream.use { it.write(payload.toString().toByteArray(Charsets.UTF_8)) }
        val stream = if (connection.responseCode in 200..299) connection.inputStream else connection.errorStream
        val responseText = stream.bufferedReader().use { it.readText() }
        connection.disconnect()
        val json = JSONObject(responseText)
        if (json.has("reply")) json.getString("reply") else "Backend error: ${json.optString("error", "Unknown error")}"
    } catch (e: Exception) {
        "NOVA backend से कनेक्शन नहीं हो पाया। Backend URL और internet connection जाँचें। (${e.javaClass.simpleName})"
    }
}
