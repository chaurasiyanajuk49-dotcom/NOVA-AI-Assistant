import express from "express";
import dotenv from "dotenv";

dotenv.config();
const app = express();
app.use(express.json({ limit: "32kb" }));

app.get("/health", (_req, res) => res.json({ ok: true, service: "NOVA AI" }));

async function askGemini(message) {
  if (!process.env.GEMINI_API_KEY) throw new Error("Gemini API key is not configured");
  const model = process.env.GEMINI_MODEL || "gemini-2.5-flash";
  const url = `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${process.env.GEMINI_API_KEY}`;
  const response = await fetch(url, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      system_instruction: {
        parts: [{ text: "You are NOVA AI, a helpful, safe personal assistant. Reply in the language used by the user, Hindi or English. Be concise and clear." }]
      },
      contents: [{ role: "user", parts: [{ text: message }] }]
    })
  });
  const data = await response.json();
  if (!response.ok) throw new Error(data.error?.message || `Gemini HTTP ${response.status}`);
  const text = data.candidates?.[0]?.content?.parts?.map(p => p.text || "").join("").trim();
  if (!text) throw new Error("Gemini returned an empty response");
  return text;
}

async function askOpenAI(message) {
  if (!process.env.OPENAI_API_KEY) throw new Error("OpenAI API key is not configured");
  const response = await fetch("https://api.openai.com/v1/responses", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "Authorization": `Bearer ${process.env.OPENAI_API_KEY}`
    },
    body: JSON.stringify({
      model: process.env.OPENAI_MODEL || "gpt-6.2-astra",
      instructions: "You are NOVA AI, a helpful, safe personal assistant. Reply in the language used by the user, Hindi or English. Be concise and clear.",
      input: message
    })
  });
  const data = await response.json();
  if (!response.ok) throw new Error(data.error?.message || `OpenAI HTTP ${response.status}`);
  const text = data.output?.flatMap(item => item.content || [])
    .filter(part => part.type === "output_text")
    .map(part => part.text).join("").trim();
  if (!text) throw new Error("OpenAI returned an empty response");
  return text;
}

app.post("/chat", async (req, res) => {
  const message = typeof req.body?.message === "string" ? req.body.message.trim() : "";
  const provider = req.body?.provider || "hybrid";
  if (!message || message.length > 8000) {
    return res.status(400).json({ error: "Message is required and must be under 8000 characters." });
  }

  try {
    if (provider === "gemini") return res.json({ reply: await askGemini(message), provider: "gemini" });
    if (provider === "openai") return res.json({ reply: await askOpenAI(message), provider: "openai" });

    // Hybrid mode: try Gemini first, then OpenAI as fallback.
    try {
      return res.json({ reply: await askGemini(message), provider: "gemini" });
    } catch (geminiError) {
      try {
        return res.json({ reply: await askOpenAI(message), provider: "openai", fallback: true });
      } catch (openaiError) {
        return res.status(502).json({
          error: `Both AI providers failed. Gemini: ${geminiError.message}. OpenAI: ${openaiError.message}`
        });
      }
    }
  } catch (error) {
    return res.status(502).json({ error: error.message || "AI request failed" });
  }
});

const port = Number(process.env.PORT || 3000);
app.listen(port, "0.0.0.0", () => console.log(`NOVA backend listening on port ${port}`));
